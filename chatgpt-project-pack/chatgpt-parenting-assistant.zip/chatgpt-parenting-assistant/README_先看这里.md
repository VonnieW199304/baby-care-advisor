# ChatGPT 朋友测试包

版本：`GPT-PROJECT-2026-08-27-v3`

不需要安装插件，也不需要懂 Skill。使用 ChatGPT 的 Project Instructions 即可。

## 推荐安装：三个 Project

在 ChatGPT 侧边栏分别新建三个 Project：

1. `宝宝行为与发育`：复制 `01_宝宝行为与发育_Project_Instructions.md` 全文到 Project instructions。
2. `观点鉴别`：复制 `02_观点鉴别_Project_Instructions.md` 全文到 Project instructions。
3. `消费决策`：复制 `03_消费决策_Project_Instructions.md` 全文到 Project instructions。

入口通常在 Project 右上角 `… → Project settings → Project instructions`。不同 ChatGPT 版本的文字可能略有差异。

三个 Project 分开使用，路由最稳定。只想少建一个 Project 时，可以复制 `04_单Project统一入口_Instructions.md`，但不建议用统一入口处理药物、急症、婴儿睡眠安全、儿童产品停止条件或召回。

## 怎么用

正常提问即可，不需要填写表格，也不需要写 Skill 名称：

- `宝宝最近一放床就醒，怎么办？`
- `这张截图说抱睡会破坏独立性，靠谱吗？`
- `盒马这包青虾仁能不能给宝宝吃？`

可以直接发一句话、截图、商品照片、文章摘录或后续补充。AI 应先回答目前能判断的部分；信息不足时再询问真正会改变结论的内容，并在补充后给整合方案。

宝宝 Project 可以选择上传月龄、体检、喂养、睡眠或发育记录，但这不是首次提问的前置条件。共享对话前先删除姓名、完整生日、医院、地址、学校和账号等隐私。

## 怎么反馈

完成一轮问答后，只输入：

```text
反馈
```

AI 会生成一个完整、可复制的反馈代码块。直接把代码块转发给测试发起人即可，不需要另外填表。

也可以顺手带一句感受：

```text
反馈：回答还是有点机械
```

反馈不会自动上传或发送。转发前请再次检查宝宝和家庭隐私。

更详细说明见 `05_使用与反馈.md`。
